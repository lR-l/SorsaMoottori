import { SorsaEngine } from "./js/sorsa_engine.js";

let sorsa_engine = new SorsaEngine(
  document.getElementsByTagName("body")[0],
  window.innerWidth / 2,
  window.innerHeight / 2,
  100,
  100,
  true
);
