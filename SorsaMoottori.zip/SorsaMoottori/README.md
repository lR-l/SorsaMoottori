# SorsaMoottori v0.1

## Usage
	- import { SorsaEngine } from "YOUR_PATH_TO /sorsa_engine.js";
	- create engine with 
	new SorsaEngine(viewelement, target_x, target_y, target_width, target_height, enable_audio);
		- viewelement, element to which the canvases will be added
		- target_x and target_y are the topleft mouse screen coordinates where the effects are triggered
		- target_width and target_height if you need area where the effects are triggered
		- enable_audio, true or false to set audio effects when target area/point is reached
	- Tunables are located in sorsa_common.js (paths,image scale and size)
