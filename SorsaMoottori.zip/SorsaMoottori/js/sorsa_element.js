import { SC_IMAGE_SIZE, SC_IMG_PATH, SC_IMG_SCALE } from "./sorsa_common.js";

class SorsaElement {
  constructor(direction, pos_from_cursor, spritesheet_data) {
    this.cursor_offset_x = null;
    this.cursor_offset_y = null;
    this.rotation = 0;
    this.direction = direction;
    this.canvas = document.createElement("canvas");
    this.canvas.width = SC_IMAGE_SIZE;
    this.canvas.height = SC_IMAGE_SIZE;
    this.image = null;
    this.current_frame = 0;
    this.current_frame_timestamp = null;
    this.last_frame_timestamp = null;
    this.spritesheet_data = spritesheet_data;
    this.canvas.style.transition = "all 2s";
    this.destination_offset_x = null;
    this.destination_offset_y = null;
    this.destination_rotation = null;
    this.pos_from_cursor = pos_from_cursor;
    this.static_effect = false;
    this.has_color = false;
    this.color_data = null;
    this.image_canvas = document.createElement("canvas");

    this.canvas.style.position = "absolute";

    this.loadImage();

    return this;
  }

  setOffsetPosition(cursor_mx, cursor_my) {
    this.cursor_offset_x = Math.random() * 100 * this.pos_from_cursor;
    this.cursor_offset_y = Math.random() * 100 * this.pos_from_cursor;

    this.canvas.style.left = this.cursor_offset_x + cursor_mx + "px";
    this.canvas.style.top = this.cursor_offset_y + cursor_my + "px";

    this.canvas.style.transform = "rotate(" + this.randomRotation() + "deg)";
  }

  setDestinationOffsets(destination_x, destination_y, destination_rotation) {
    this.destination_offset_x = destination_x;
    this.destination_offset_y = destination_y;
    this.destination_rotation = destination_rotation;
  }

  atDestination() {
    this.cursor_offset_x = this.destination_offset_x;
    this.cursor_offset_y = this.destination_offset_y;
  }

  randomRotation() {
    let direction = Math.round(Math.random());

    if (direction == 0) {
      return -Math.random() * 361;
    } else {
      return Math.random() * 361;
    }
  }

  loadImage() {
    let image = document.createElement("img");
    image.object = this;
    image.onload = function() {
      this.object.image_canvas.width = this.width;
      this.object.image_canvas.height = this.height;

      let cxt = this.object.image_canvas.getContext("2d");
      cxt.drawImage(this, 0, 0);
      this.object.color_data = this.object.setColor(true);

      if (this.object.color_data != null) {
        cxt.putImageData(this.object.color_data, 0, 0);
      }
    };

    image.src = SC_IMG_PATH;
    this.image = image;
  }

  switchImage(frame_timestamp) {
    if (this.spritesheet_data != null) {
      let frames_data = this.spritesheet_data.frames;
      let frame_duration = frames_data[this.current_frame].duration;

      if (this.last_frame_timestamp == null) {
        this.last_frame_timestamp = frame_timestamp;

        if (this.current_frame < this.spritesheet_data.frames.length - 1) {
          this.current_frame++;
        } else {
          this.current_frame = 0;
        }
      }

      if (this.current_frame < this.spritesheet_data.frames.length - 1) {
        if (frame_timestamp - this.last_frame_timestamp >= frame_duration) {
          this.current_frame++;
          this.last_frame_timestamp = frame_timestamp;
        }
      } else {
        this.current_frame = 0;
      }

      this.renderImage();
    }
  }

  renderImage() {
    let frame_data = this.spritesheet_data.frames[this.current_frame].frame;
    let cxt = this.canvas.getContext("2d");
    cxt.clearRect(0, 0, SC_IMAGE_SIZE, SC_IMAGE_SIZE);
    /*
        if (this.rotation != 0) {
            cxt.translate(this.canvas.width / 2, this.canvas.height / 2);
            cxt.rotate(this.rotation); // * Math.PI / 180
            cxt.translate(-this.canvas.width / 2, -this.canvas.height / 2);
            cxt.drawImage(this.image, frame_data.x, frame_data.y, frame_data.w, frame_data.h, 0, 0, SC_IMAGE_SIZE, SC_IMAGE_SIZE);
            this.rotation = 0;

        } else {
            cxt.drawImage(this.image, frame_data.x, frame_data.y, frame_data.w, frame_data.h, 0, 0, SC_IMAGE_SIZE, SC_IMAGE_SIZE);
        }
        */

    cxt.drawImage(
      this.image_canvas,
      frame_data.x,
      frame_data.y,
      frame_data.w,
      frame_data.h,
      0,
      0,
      SC_IMAGE_SIZE * SC_IMG_SCALE,
      SC_IMAGE_SIZE * SC_IMG_SCALE
    );
    /*

        if (this.static_effect) {
            this.color_data = this.setColor(false);
        }

        */
  }

  setColor(set_allpixels) {
    let cxt = this.image_canvas.getContext("2d");
    let imagedata = cxt.getImageData(
      0,
      0,
      this.image_canvas.width,
      this.image_canvas.height
    );

    let color_r = Math.random() * 156; //256
    let color_g = Math.random() * 156;
    let color_b = Math.random() * 156;

    for (let i = 0; i < imagedata.data.length; i += 4) {
      let r = imagedata.data[i];
      let g = imagedata.data[i + 1];
      let b = imagedata.data[i + 2];

      if (
        !(
          (r == 255 && g == 255 && b == 255) ||
          (r == 0 && g == 0 && b == 0) ||
          (r == 223 && g == 113 && b == 38)
        )
      ) {
        if (set_allpixels) {
          if (r + color_r > 255) {
            imagedata.data[i] -= color_r;
          } else {
            imagedata.data[i] += color_r;
          }

          if (g + color_g > 255) {
            imagedata.data[i + 1] -= color_g;
          } else {
            imagedata.data[i + 1] += color_g;
          }

          if (b + color_b > 255) {
            imagedata.data[i + 2] -= color_b;
          } else {
            imagedata.data[i + 2] += color_b;
          }
          /*
                    imagedata.data[i] = color_r;
                    imagedata.data[i + 1] = color_g;
                    imagedata.data[i + 2] = color_b;
                    */
        } else {
          imagedata.data[i] = Math.random() * 256;
          imagedata.data[i + 1] = Math.random() * 256;
          imagedata.data[i + 2] = Math.random() * 256;
        }
      }
    }
    return imagedata;
  }
}

export { SorsaElement };
