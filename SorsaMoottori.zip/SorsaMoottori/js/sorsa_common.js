export const SC_SPIRTES_PATH = "/sprites";
export const SC_JSON_PATH = SC_SPIRTES_PATH + "/sorsa_gen1.json";
export const SC_IMG_PATH = SC_SPIRTES_PATH + "/sorsa_gen1.png";
export const SC_IMAGE_SIZE = 128;
export const SC_SOUNDS_PATH = "/sounds";
export const SC_DESTINATION_SOUND_PATH = "/uiuiui.mp3";
export const SC_FLIGHT_SOUND_PATH = "/flap.mp3";
export const SC_IMG_SCALE = 0.5;
