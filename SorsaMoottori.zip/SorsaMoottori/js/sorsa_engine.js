import { SorsaElement } from "./sorsa_element.js";
import {
	SC_JSON_PATH,
	SC_SOUNDS_PATH,
	SC_FLIGHT_SOUND_PATH,
	SC_DESTINATION_SOUND_PATH,
} from "./sorsa_common.js";

class SorsaEngine {
	constructor(
		viewelement,
		target_x,
		target_y,
		target_width,
		target_height,
		enable_audio
	) {
		this.sorsat = [];
		this.viewelement = viewelement;
		this.animationrequest_id = null;
		this.target_x = target_x;
		this.target_y = target_y;
		this.target_width = target_width;
		this.target_height = target_height;
		this.flight_sound_playing = false;
		this.destination_sound_playing = false;
		this.destination_sound_effect = null;
		this.flight_sound_effect = null;
		this.flight_sound_playing = false;
		this.spritesheetdata = null;
		this.enable_audio = enable_audio;

		this.loadJSON().then(
			function (result) {
				this.spritesheetdata = result;
				this.loadSoundEffects();
				this.setupFlightObjects();
				this.setFlightPLan();
				this.startFlapping();
			}.bind(this)
		);
	}

	loadSoundEffects() {
		this.destination_sound_effect = document.createElement("audio");
		this.flight_sound_effect = document.createElement("audio");

		this.destination_sound_effect.src =
			SC_SOUNDS_PATH + SC_DESTINATION_SOUND_PATH;
		this.flight_sound_effect.src = SC_SOUNDS_PATH + SC_FLIGHT_SOUND_PATH;

		this.destination_sound_effect.addEventListener(
			"ended",
			(_) =>
				function () {
					this.destination_sound_playing = false;
				}
		);

		this.flight_sound_effect.addEventListener(
			"ended",
			(_) =>
				function () {
					this.flight_sound_playing = false;
				}
		);
	}

	loadJSON() {
		let promise = new Promise(function (resolve, reject) {
			let http = new XMLHttpRequest();
			http.open("GET", SC_JSON_PATH);
			http.setRequestHeader("Content-type", "application/json");
			http.onreadystatechange = function () {
				if (http.readyState == 4 || http.readyState == 200) {
					let response = JSON.parse(http.responseText);
					resolve(response);
				}
			};
			http.send();
		});

		return promise;
	}

	startFlapping() {
		this.animationrequest_id = requestAnimationFrame(this.flapping.bind(this));
	}

	flapping(highrestimestamp) {
		for (let sorsa in this.sorsat) {
			this.sorsat[sorsa].switchImage(highrestimestamp);
		}
		this.animationrequest_id = requestAnimationFrame(this.flapping.bind(this));
	}

	setupFlightObjects() {
		let sorsa = new SorsaElement(0, 1, this.spritesheetdata);
		sorsa.setDestinationOffsets(5, 5, 0);
		this.viewelement.append(sorsa.canvas);
		this.sorsat.push(sorsa);

		let sorsa2 = new SorsaElement(0, -1, this.spritesheetdata);
		sorsa2.setDestinationOffsets(-75, -75, 0);
		this.viewelement.append(sorsa2.canvas);
		this.sorsat.push(sorsa2);
	}

	setFlightPLan() {
		document.addEventListener("mousemove", (mouseevent) => {
			let mx = mouseevent.clientX;
			let my = mouseevent.clientY;
			//console.log(`Mouse pos ( ${mx},${my} ? (${this.targetx},${this.targety})`);

			if (this.checkAtDestination(mx, my)) {
				this.destination_sound_playing = true;
				this.destination_sound_effect.play();
				this.viewelement.style.cursor = "grabbing";
			} else {
				this.flight_sound_playing = true;
				this.flight_sound_effect.play();
				this.viewelement.style.cursor = "default";
			}

			this.setPositions(mx, my);
		});
	}

	setPositions(mx, my) {
		for (let sorsa in this.sorsat) {
			this.sorsat[sorsa].setOffsetPosition(mx, my);
		}
	}

	setDestination(target_x, target_y, target_width, target_height) {
		this.target_x = target_x;
		this.target_y = target_y;
		this.target_width = target_width;
		this.target_height = target_height;
	}

	checkAtDestination(mx, my) {
		if (
			mx > this.target_x - this.target_width &&
			mx < this.target_x + this.target_width &&
			my > this.target_y - this.target_height &&
			my < this.target_y + this.target_height
		) {
			return true;
		} else {
			return false;
		}
	}
}

export { SorsaEngine };
